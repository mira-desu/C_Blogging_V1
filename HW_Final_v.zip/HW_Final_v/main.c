#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LENGTH 100

struct User {
    char name[LENGTH];
    char email[LENGTH];
    char contactInfo[LENGTH]; //phone number
    char username[LENGTH];
    char password[LENGTH];
    struct User* next;
};

struct BlogPost {
    char date[LENGTH];
    char author[LENGTH];
    char time[LENGTH];
    char keywords[LENGTH];
    char *content; // content is dynamic
    struct BlogPost* next;
};

//List of functions
void signUp(struct User** users);
int logIn(struct User* users, struct User** currentUser);
void subMenu(struct User* currentUser, struct BlogPost** blogs);

//submenu options
void createBlogPost(struct User* currentUser, struct BlogPost** blogs);
void editBlogPost(struct User* currentUser, struct BlogPost** blogs);
void deleteBlogPost(struct User* currentUser, struct BlogPost** blogs);
void searchBlogPost(struct BlogPost* blogs);

void printBlogPost(const struct BlogPost* post);
void freeUserList(struct User* userList);
void freeBlogList(struct BlogPost* blogList);

// File handling functions
void userfileHandler(const char *filename, struct User** users, int write);
void blogPostfileHandler(const char *filename, struct BlogPost** blogs, int write);
// Function to save a single blog post to a file
void saveBlogPostToFile(const struct BlogPost* post);

// Functions to save the entire list of blog posts / users to file
void saveBlogsToFile(const struct BlogPost* blogs);
void saveUsersToFile(const struct User* users);
//main function initializes user and blog variables, reads data from files, and presents a menu for user interaction


int main() {

    struct User* users = NULL;
    struct BlogPost* blogs = NULL;
    struct User* currentUser = NULL;

    int choice;

    //read user and blog data from files
    userfileHandler("users.txt", &users, 0);
    blogPostfileHandler("blog_posts.txt", &blogs, 0);

    //main menu, scanf expect only integer here if user enters different data type it will become error!!!
    while (1) {
        printf("\n-- Main Menu --\n");
        printf("1. Sign Up\n");
        printf("2. Log In\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                signUp(&users);
                break;
            case 2:
                // Log in and access submenu for logged-in users
                if (logIn(users, &currentUser)) {
                    subMenu(currentUser, &blogs);
                }
                break;
            case 3:
                // Exit the program, freeing allocated memory
                printf("Exiting the program.\n");
                freeUserList(users);
                freeBlogList(blogs);
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    }
}

// Function for user sign-up
void signUp(struct User** users) {
    //allocating memory for user
    struct User* user =(struct User*)malloc(sizeof(struct User));
    if (user == NULL) {
        printf("Memory allocation failed. Cannot sign up.\n");
        return;
    }

    //getting user information from user input
    printf("Enter your full name: ");
    scanf(" %[^\n]", user->name); //read until newline

    printf("Enter your email address: ");
     //fgets(email, sizeof(email), stdin); if use fgets i must call array and other elements here
    scanf(" %[^\n]", user->email);

    printf("Enter your contact information: ");
    scanf(" %[^\n]", user->contactInfo);

    printf("Enter your user name: ");
    scanf(" %[^\n]", user->username);

    printf("Enter your new password: ");
    scanf(" %[^\n]", user->password);

    //add the new user to the linked list
    user->next = *users;
    *users = user;

    printf("Sign up successful. You can now log in.\n");

    //save updated user data to file
    userfileHandler("users.txt", users, 1);
}

// Function for user log-in
int logIn(struct User* users, struct User** currentUser) {
    char username[LENGTH];
    char password[LENGTH];
 //getting user inputs for username and password
    printf("Enter your username: ");
    scanf(" %[^\n]", username);

    printf("Enter your password: ");
    scanf(" %[^\n]", password);

    struct User* user = users;
    //checking username and password is correct or not
    while (user) {
        if (strcmp(user->username, username)==0 && strcmp(user->password, password)==0) {
            *currentUser = user;
            printf("Log in successful. Welcome, %s!\n", (*currentUser)->name);
            return 1;
        }
        user = user->next;
    }
 printf("Username or password is not correct. Please try again.\n");
    return 0;
}

// Function for the sub-menu
void subMenu(struct User* currentUser, struct BlogPost** blogs) {
    int choice;
//submenu options prompting from user and activating functions related to choose
//here also program excepts numbers
    while (1) {
        printf("\n-- Sub-Menu --\n");
        printf("1. Create a blog post\n");
        printf("2. Edit a blog post\n");
        printf("3. Delete a blog post\n");
        printf("4. Search a blog post\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                createBlogPost(currentUser, blogs);
                break;
            case 2:
                editBlogPost(currentUser, blogs);
                break;
            case 3:
                deleteBlogPost(currentUser, blogs);
                break;
            case 4:
                searchBlogPost(*blogs);
                break;
            case 5:
                printf("Logging out. Goodbye, %s!\n", currentUser->name);
                currentUser = NULL;
                return;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    }
}
// Function to create a blog post (free if content is null)
void createBlogPost(struct User* currentUser, struct BlogPost** blogs) {
    struct BlogPost* post = (struct BlogPost*)malloc(sizeof(struct BlogPost));

    if (post == NULL) {
        printf("Memory allocation failed.Cannot create a blog post.\n");
        return;
    }
    // Initializing content to NULL
    post->content = NULL;

    printf("Enter date (yyyy.mm.dd): ");
    scanf(" %[^\n]", post->date);

    strcpy(post->author, currentUser->name);

    printf("Enter your time(morning/afternoon/nigth): ");
    scanf(" %[^\n]", post->time);

    printf("Enter keywords: ");
    scanf(" %[^\n]", post->keywords);

    int len;
    printf("Enter length of content:\n ");
    scanf("%d", &len);
    //after reading the length of content
    //allocate memory for content
    post->content=(char*)malloc(sizeof(char) * (len + 1));// adding 1 for terminating zero

    if (post->content == NULL) {
        printf("Memory allocation failed for content. Cannot create a blog post.\n");
//freee allocated memory for post before returning
        free(post);
        return;
    }
    printf("\nEnter your content below:\n");
    scanf(" %[^\n]", post->content);

    //save the entire list of blog posts to the file after adding the new post
    saveBlogPostToFile(post);
    post->next = *blogs;
    *blogs = post;  // update the head of the list
    printf("Blog post created successfully.\n");
}

void editBlogPost(struct User* currentUser, struct BlogPost** blogs) {
    if (*blogs == NULL) {
        printf("No blog posts found. Cannot edit.\n");
        return;
    }
    // Display user's existing blog posts
    int index = 0;
    struct BlogPost* post = *blogs;

    printf("Your blog posts:\n");
    while (post) {
        if (strcmp(post->author, currentUser->name) == 0) {
            printf("%d. Date: %s, Time: %s, Keywords: %s\n", index, post->date, post->time, post->keywords);
        }
        index++;
        post = post->next;
    }

    // Prompting the user to choose the index of the blog post to edit
    printf("Enter the index of the blog post to edit (0 to %d): ", index - 1);
    scanf("%d", &index);

    // Find the selected blog post
    post = *blogs;
    int i = 0;
    while (post) {
        if (i == index && strcmp(post->author, currentUser->name) == 0) {
            break;
        }
        i++;
        post = post->next;
    }

    //check for invalid index
    if (post == NULL) {
        printf("Invalid index. Please try again.\n");
        return;
    }

    //Display current details and prompt for modifications
    printf("Current date: %s\n", post->date);
    printf("Enter new date (or leave blank to keep current): ");
    scanf(" %[^\n]", post->date);

    printf("Current time: %s\n", post->time);
    printf("Enter new time (morning/afternoon/night): ");
    scanf(" %[^\n]", post->time);

    printf("Current keywords: %s\n", post->keywords);
    printf("Enter new keywords (or leave blank to keep current): ");
    scanf(" %[^\n]", post->keywords);

    printf("Current content: %s\n", post->content);
    printf("Enter the length of new content: ");
    int newContentLen;
    scanf("%d", &newContentLen);

    //free existing content before reading new content
    free(post->content);

    //allocate memory for new content
    post->content = (char*)malloc(sizeof(char) * (newContentLen + 1));

    if (post->content == NULL) {
        printf("Memory allocation failed for new content.\n");
        return;
    }

    printf("Enter new content (or leave blank to keep current):\n");
    //read the new content
    scanf(" %[^\n]", post->content);
    post->content[newContentLen] = '\0';

    //Save the entire list of blog posts to the file after editing
    saveBlogsToFile(*blogs);

    printf("Blog post edited successfully.\n");
}
// Function to delete a blog post
void deleteBlogPost(struct User* currentUser, struct BlogPost** blogs) {
    if (*blogs == NULL) {
        printf("No blog posts found. Cannot delete.\n");
        return;
    }

    int index = 0;
    struct BlogPost* post = *blogs;
//printing all posts
    printf("Your blog posts:\n");
    while (post) {
        if (strcmp(post->author, currentUser->name) == 0) {
            printf("%d. Date: %s, Time: %s, Keywords: %s\n", index, post->date, post->time, post->keywords);
        }
        index++;
        post = post->next;
    }

    printf("Enter the index of the blog post to delete (0 to %d): ", index - 1);
    scanf("%d", &index);

    post = *blogs;
    struct BlogPost* prev = NULL;
    int i = 0;
//check the indices
    while (post) {
        if (i == index && strcmp(post->author, currentUser->name) == 0) {
            break;
        }
        i++;
        prev = post;
        post = post->next;
    }

    if (post == NULL) {
        printf("Invalid index. Please try again.\n");
        return;
    }

    if (prev == NULL) {
        //deleting the first node
        *blogs = post->next;
    } else {
        prev->next = post->next;
    }

    //save the entire list of blog posts to the file after deletion
    saveBlogsToFile(*blogs);

    free(post->content); // Free the content before freeing the node
    free(post);
    printf("Blog post deleted successfully.\n");
}

// Function to free the user list
void freeUserList(struct User* userList) {
    while (userList) {
        struct User* temp = userList;
        userList = userList->next;
        free(temp);
    }
}

// Function to free the blog list
void freeBlogList(struct BlogPost* blogList) {
    while (blogList) {
        struct BlogPost* temp = blogList;
        blogList = blogList->next;
        free(temp->content); // Free the content before freeing the node
        free(temp);
    }
}

// Function to handle reading and writing user data to a file
void userfileHandler(const char *filename, struct User** users, int write) {
    FILE* file;

    if (write) {
        //writing user data to file but using append it prevents overwriting
        file = fopen(filename, "a");
        if (file == NULL) {
            printf("Error opening file for appending\n");
            return;
        }

        const struct User* current = *users;
        while (current != NULL) {
            fprintf(file, "%s\n%s\n%s\n%s\n%s\n---\n",
                    current->name, current->email, current->contactInfo, current->username, current->password);
            current = current->next;
        }
    } else {
        // Reading user data from file
        file = fopen(filename, "r");
        if (file == NULL) {
            // File doesn't exist yet
            return;
        }

        char buffer[LENGTH];
        struct User* lastUser = NULL;

        while (1) {
            struct User* newUser = malloc(sizeof(struct User));
            if (newUser == NULL) {
                printf("Memory allocation failed.\n");
                break;
            }
   //Read user data from file
            if (fgets(newUser->name, LENGTH, file) == NULL ||
                fgets(newUser->email, LENGTH, file) == NULL ||
                fgets(newUser->contactInfo, LENGTH, file) == NULL ||
                fgets(newUser->username, LENGTH, file) == NULL ||
                fgets(newUser->password, LENGTH, file) == NULL) {
                free(newUser);
                break;
            }
   //Remove trailing newline characters
            newUser->name[strcspn(newUser->name, "\n")] = 0;
            newUser->email[strcspn(newUser->email, "\n")] = 0;
            newUser->contactInfo[strcspn(newUser->contactInfo, "\n")] = 0;
            newUser->username[strcspn(newUser->username, "\n")] = 0;
            newUser->password[strcspn(newUser->password, "\n")] = 0;

            newUser->next = NULL;

            // Add user to the linked list
            if (lastUser == NULL) {
                *users = newUser;
            } else {
                lastUser->next = newUser;
            }
            lastUser = newUser;
            // Read the delimiter line
            if (fgets(buffer, LENGTH, file) == NULL || strcmp(buffer, "---\n") != 0) {
                break;
            }
        } fclose(file);}
}
// Function to handle reading and writing blog post data to a file

void blogPostfileHandler(const char *filename, struct BlogPost** blogs, int write) {
    FILE* file;

    if (write) {
        //writing blog post data to file
        file = fopen(filename, "w");
        if (file == NULL) {
            printf("Error opening file for writing\n");
            return;
        }

        struct BlogPost* current = *blogs;
        while (current != NULL) {
            fprintf(file, "%s\n%s\n%s\n%s\n%s\n---\n", //format to write the blog post
                    current->date, current->author, current->time, current->keywords, current->content);
            current = current->next;
        }
    } else {
        //reading blog post data from file
        file = fopen(filename, "r");
        if (file == NULL) {
            // File doesn't exist yet
            return;
        }

        struct BlogPost* lastPost = NULL;

        while (1) {
            struct BlogPost* newPost = malloc(sizeof(struct BlogPost));
            if (newPost == NULL) {
                printf("Memory allocation failed.\n");
                break;
            }

            //allocating memory for content
            newPost->content = malloc(LENGTH * sizeof(char));
            if (newPost->content == NULL) {
                printf("Memory allocation for content failed.\n");
                free(newPost);
                break;
            }
            //read blog post data from file
            if (fgets(newPost->date, LENGTH, file) == NULL ||
                fgets(newPost->author, LENGTH, file) == NULL ||
                fgets(newPost->time, LENGTH, file) == NULL ||
                fgets(newPost->keywords, LENGTH, file) == NULL ||
                fgets(newPost->content, LENGTH, file) == NULL) {
                free(newPost->content);
                free(newPost);
                break;
            }

            //remove trailing newline characters
            newPost->date[strcspn(newPost->date, "\n")] = 0;
            newPost->author[strcspn(newPost->author, "\n")] = 0;
            newPost->time[strcspn(newPost->time, "\n")] = 0;
            newPost->keywords[strcspn(newPost->keywords, "\n")] = 0;
            newPost->content[strcspn(newPost->content, "\n")] = 0;

            newPost->next = NULL;

            //add blogpost to the linked list
            if (lastPost == NULL) {
                *blogs = newPost;
            } else {
                lastPost->next = newPost;
            }

            lastPost = newPost;
        }

        fclose(file);
    }
}
// Function to search for a blog post
void searchBlogPost(struct BlogPost* blogs){
    int choice;

    printf("\n-- Search Options --\n");
    printf("1. Search by time\n");
    printf("2. Search by date\n");
    printf("3. Search by keyword\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1: {
            char time[LENGTH];

            printf("Enter time (e.g., morning, afternoon, evening): ");
            scanf(" %[^\n]", time);

            printf("\n-- Blog Posts Found --\n");
            struct BlogPost* post = blogs;

            while (post) {
                if (strstr(post->time, time) != NULL) {
                    printBlogPost(post);
                }
                post = post->next;
            }
            break;
        }
        case 2: {
            char date[LENGTH];

            printf("Enter date (yyyy.mm.dd): ");
            scanf(" %[^\n]", date);

            printf("\n-- Blog Posts Found --\n");
            struct BlogPost* post = blogs;

            while (post) {
                if (strcmp(post->date, date) == 0) {
                    printBlogPost(post);
                }
                post = post->next;
            }
            break;
        }
        case 3: {
            char keyword[LENGTH];

            printf("Enter keyword: ");
            scanf(" %[^\n]", keyword);

            printf("\n-- Blog Posts Found --\n");
            struct BlogPost* post = blogs;

            while (post) {
                if (strstr(post->keywords, keyword) != NULL) {
                    printBlogPost(post);
                }
                post = post->next;
            }
            break;
        }
        default:
            printf("Invalid choice. Please try again.\n");
            break;
    }
}
//function to print blogpost
void printBlogPost(const struct BlogPost* post) {
    printf("Date: %s\n", post->date);
    printf("Author: %s\n", post->author);
    printf("Time: %s\n", post->time);
    printf("Keywords: %s\n", post->keywords);
    printf("Content:\n%s\n", post->content);  // Print content with newline for better readability
    printf("---\n"); //for readablity
}

void saveBlogPostToFile(const struct BlogPost* post) {
    //opening blog_posts.txt file and appending it
    FILE* file = fopen("blog_posts.txt", "a");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }
//saving date, author, time, keywords, and content to file
    fprintf(file, "%s\n%s\n%s\n%s\n%s\n%s\n",
            post->date, post->author, post->time, post->keywords, post->content, "---");

    fclose(file);
}
//We need a functions to iterate over the linked list of users and write each user's information to a file.
void saveUsersToFile(const struct User* users) {
    FILE* file = fopen("users.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
    }

    const struct User* current = users;
    //saving current users information to file
    while (current != NULL) {
        fprintf(file, "%s\n%s\n%s\n%s\n%s\n---\n",
                current->name, current->email, current->contactInfo, current->username, current->password);
        current = current->next;
    }
    fclose(file);
}
void saveBlogsToFile(const struct BlogPost* blogs) {
    FILE* file = fopen("blog_posts.txt", "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return;
}
    const struct BlogPost* current = blogs;
    //saving current users blog  to blogpost file
    while (current != NULL) {
        fprintf(file, "%s\n%s\n%s\n%s\n%s\n%s\n",
                current->date, current->author, current->time, current->keywords, current->content, "---");
        current = current->next;
    }
    fclose(file);
}
